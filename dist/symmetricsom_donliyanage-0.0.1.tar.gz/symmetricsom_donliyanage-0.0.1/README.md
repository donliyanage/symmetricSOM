# symmetricSOM
Self Organising Map (SOM) with symmetry based classifier/regressor 
